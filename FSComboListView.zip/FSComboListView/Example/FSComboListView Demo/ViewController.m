//
//  ViewController.m
//  FSComboListView Demo
//
//  Created by John on 2/22/16.
//  Copyright © 2016 John. All rights reserved.
//

#import "ViewController.h"
#import "FSComboListView.h"

@interface ViewController ()<FSComboPickerViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    [self setupComboListView];
}


#pragma mark - FSComboListView

- (void)setupComboListView
{
    FSComboListView *comboListView = [[FSComboListView alloc] initWithValues:@[@"Value 1", @"Value 2", @"Value 3",@"Value 4", @"Value 5"] frame:CGRectMake(0, 0, 300, 40)];
    
    comboListView.center = self.view.center;
    
    [self.view addSubview:comboListView];
}


- (void) comboboxOpened:(FSComboListView *)combobox
{
    NSLog(@"comboboxOpened");
}

- (void) comboboxClosed:(FSComboListView *)combobox
{
    NSLog(@"comboboxClosed");
}

- (void) comboboxChanged:(FSComboListView *)combobox toValue:(NSString *)toValue
{
    NSLog(@"comboboxChanged to value %@",toValue);
}


@end
