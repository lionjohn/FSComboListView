//
//  UIImage+FSAdditions.h
//  HouseLoan
//
//  Created by john on 6/5/14.
//  Copyright (c) 2014 jingjing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (FSAdditions)

- (UIImage *)imageWithTintColor:(UIColor *)color;

@end
